PingFederate Log4j 2 version 2.16.0 update
==========================================

Introduction
------------
This package contains Log4j 2 version 2.16.0 jar files addressing CVE-2021-44228 for PingFederate 8.0 and newer.


Bill of materials
-----------------
- dist/pingfederate/server/default/lib/log4j-jcl.jar
- dist/pingfederate/server/default/lib/log4j-1.2-api.jar
- dist/pingfederate/server/default/lib/log4j-slf4j-impl.jar
- dist/pingfederate/server/default/lib/log4j-core.jar
- dist/pingfederate/server/default/lib/log4j-api.jar
- dist/pingfederate/server/default/lib/log4j-jul.jar
- dist/pingfederate/server/default/lib/disruptor.jar
- README.txt


Installation Log4j 2 version 2.16.0
-----------------------------------
Log4j 2 version 2.16.0 can be installed on PingFederate 8.0 and newer by replacing the provided jar files.
To install, please copy the contents of "dist/pingfederate/server/default/lib" directory to each PingFederate
server in your cluster under "<pf_install>/pingfederate/server/default/lib".

------------------------
Copyright 2021
Ping Identity Corporation
1001 17th Street, Suite 100
Denver, CO 80202
U.S.A.